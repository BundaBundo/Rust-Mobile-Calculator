package com.RustM.calculator;

import java.util.*;

public class Calculator {

    public static class Result {
        public Map<String, Long> raw = new LinkedHashMap<>();
        public Map<String, Long> direct = new LinkedHashMap<>();
        public Map<String, List<String[]>> directNotes = new LinkedHashMap<>();
        public long sulfurUsed = 0;
        public long gunpowderCrafted = 0;
        public boolean hasCraftTime = false;
        public String craftTimeText = "";
        public long furnaceTotalSecs = 0;
        public long furnaceLongestSecs = 0;
        public int furnaceCount = 0;
        public List<String[]> furnaceRows = new ArrayList<>();
        public long grandTotalSecs = 0;
        public String item;
        public int qty;
    }

    public static int ceilDiv(long a, long b) {
        return (int) Math.ceil((double) a / b);
    }

    public static String hms(long s) {
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        return h + "h " + m + "m " + sec + "s";
    }

    public static String fmt(long n) {
        return String.format(Locale.US, "%,d", n);
    }

    public static Map<String, Long> calcRaw(String item, int qty,
                                            boolean mixing,
                                            long[] sulfurTracker) {
        String key = item.toLowerCase().trim();
        Map<String, Integer> recipe;
        int batch;

        if (key.equals("gunpowder") && mixing) {
            recipe = Recipes.RECIPES.get("gunpowder_mixing");
            batch = Recipes.BATCH_SIZE.get("gunpowder_mixing");
        } else {
            recipe = Recipes.RECIPES.get(key);
            batch = Recipes.BATCH_SIZE.getOrDefault(key, 1);
        }
        if (recipe == null) return null;

        int crafts = ceilDiv(qty, batch);
        Map<String, Long> totals = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : recipe.entrySet())
            totals.put(e.getKey(), (long) e.getValue() * crafts);

        Map<String, Long> final_ = new LinkedHashMap<>();
        for (Map.Entry<String, Long> e : totals.entrySet()) {
            String ing = e.getKey();
            long amt = e.getValue();
            if (ing.equals("sulfur") && sulfurTracker != null)
                sulfurTracker[0] += amt;

            if (Recipes.RECIPES.containsKey(ing)
                    && !Recipes.RAW_MATERIALS.contains(ing)) {
                Map<String, Long> sub = calcRaw(ing, (int) amt, mixing, sulfurTracker);
                if (sub != null)
                    for (Map.Entry<String, Long> se : sub.entrySet())
                        final_.merge(se.getKey(), se.getValue(), Long::sum);
            } else {
                final_.merge(ing, amt, Long::sum);
            }
        }
        return final_;
    }

    public static Result calculate(String item, int qty, boolean mixing) {
        Result r = new Result();
        r.item = item;
        r.qty = qty;

        String key = item.toLowerCase().trim();

        long[] sulfur = new long[1];
        Map<String, Long> raw;
        if (key.equals("gunpowder") && mixing)
            raw = calcRaw("gunpowder_mixing", qty, true, sulfur);
        else
            raw = calcRaw(key, qty, mixing, sulfur);

        if (raw == null) return null;
        r.raw = raw;
        r.sulfurUsed = sulfur[0];

        String recipeKey = (key.equals("gunpowder") && mixing)
            ? "gunpowder_mixing" : key;
        Map<String, Integer> recipe = Recipes.RECIPES.get(recipeKey);
        int batch = Recipes.BATCH_SIZE.getOrDefault(recipeKey, 1);
        if (recipe != null) {
            int crafts = ceilDiv(qty, batch);
            for (Map.Entry<String, Integer> e : recipe.entrySet()) {
                long total = (long) e.getValue() * crafts;
                r.direct.put(e.getKey(), total);
                buildNote(r, e.getKey(), total, mixing);
            }
        }

        long gp = key.equals("gunpowder") ? qty : raw.getOrDefault("gunpowder", 0L);
        if (!mixing && gp > 0) {
            r.hasCraftTime = true;
            r.gunpowderCrafted = gp;
            long batches = ceilDiv(gp, Recipes.GUNPOWDER_PER_BATCH);
            long secs = (long) Math.ceil(batches * Recipes.GUNPOWDER_SECS_PER_BATCH);
            r.craftTimeText = "Gunpowder   " + hms(secs)
                + "  (" + fmt(batches) + " batches x "
                + Recipes.GUNPOWDER_SECS_PER_BATCH + "s)";
            r.grandTotalSecs += secs;
        }

        for (Map.Entry<String, int[]> e : Recipes.FURNACE_RATES.entrySet()) {
            long q = raw.getOrDefault(e.getKey(), 0L);
            if (q <= 0) continue;
            int fb = e.getValue()[0];
            int fs = e.getValue()[1];
            long batches = ceilDiv(q, fb);
            long secs = batches * fs;
            r.furnaceRows.add(new String[]{
                e.getKey(), fmt(batches), hms(secs)});
            r.furnaceTotalSecs += secs;
            if (secs > r.furnaceLongestSecs) r.furnaceLongestSecs = secs;
        }
        r.furnaceCount = r.furnaceRows.size();
        r.grandTotalSecs += r.furnaceTotalSecs;

        return r;
    }

    private static void buildNote(Result r, String ing, long total, boolean mixing) {
        String key = ing.toLowerCase().trim();
        Map<String, Integer> sub;
        int batch;
        if (key.equals("gunpowder") && mixing) {
            sub = Recipes.RECIPES.get("gunpowder_mixing");
            batch = Recipes.BATCH_SIZE.get("gunpowder_mixing");
        } else {
            sub = Recipes.RECIPES.get(key);
            batch = Recipes.BATCH_SIZE.getOrDefault(key, 1);
        }
        if (sub == null) return;

        int crafts = ceilDiv(total, batch);
        long gp = 0, sulfur = 0, charcoal = 0, boxes = 0;
        for (Map.Entry<String, Integer> e : sub.entrySet()) {
            long amt = (long) e.getValue() * crafts;
            switch (e.getKey()) {
                case "gunpowder": gp = amt; break;
                case "sulfur": sulfur = amt; break;
                case "charcoal": charcoal = amt; break;
                case "wood storage box": boxes = amt; break;
            }
        }

        List<String[]> notes = r.directNotes.computeIfAbsent(
            key, k -> new ArrayList<>());

        if (gp > 0)
            notes.add(new String[]{"gunpowder", "needs " + fmt(gp) + " gunpowder"});
        if (sulfur > 0) {
            long wood = ceilDiv(sulfur, 4);
            notes.add(new String[]{"sulfur",
                "needs " + fmt(sulfur) + " sulfur (" + fmt(wood) + " wood to smelt)"});
        }
        if (charcoal > 0)
            notes.add(new String[]{"charcoal",
                "needs " + fmt(charcoal) + " charcoal (" + fmt(charcoal) + " wood)"});
        if (boxes > 0)
            notes.add(new String[]{"wood storage box",
                "needs " + fmt(boxes) + " wooden storage box (" + fmt(boxes * 100) + " wood)"});
    }
}