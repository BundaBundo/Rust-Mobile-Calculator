package com.RustM.calculator;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private Spinner itemSpinner;
    private EditText qtyInput;
    private SwitchMaterial mixingSwitch;
    private ImageView resultImage;
    private Button shareButton;

    private Calculator.Result lastResult = null;
    private boolean lastMixing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemSpinner  = findViewById(R.id.itemSpinner);
        qtyInput     = findViewById(R.id.qtyInput);
        mixingSwitch = findViewById(R.id.mixingSwitch);
        resultImage  = findViewById(R.id.resultImage);
        shareButton  = findViewById(R.id.shareButton);
        Button calcButton = findViewById(R.id.calcButton);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, R.layout.spinner_item, Recipes.ITEMS);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        itemSpinner.setAdapter(adapter);

        calcButton.setOnClickListener(v -> doCalculate());
        shareButton.setOnClickListener(v -> doShare());
        resultImage.setOnClickListener(v -> doShare());
    }

    private void doCalculate() {
        String item = (String) itemSpinner.getSelectedItem();
        if (item == null) {
            Toast.makeText(this, "Pick an item first", Toast.LENGTH_SHORT).show();
            return;
        }

        String qtyStr = qtyInput.getText() == null ? "" : qtyInput.getText().toString().trim();
        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (Exception e) {
            Toast.makeText(this, "Enter a valid quantity", Toast.LENGTH_SHORT).show();
            return;
        }
        if (qty <= 0) {
            Toast.makeText(this, "Quantity must be positive", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean mixing = mixingSwitch.isChecked();
        Calculator.Result r = Calculator.calculate(item, qty, mixing);
        if (r == null) {
            Toast.makeText(this, "Recipe not found", Toast.LENGTH_SHORT).show();
            return;
        }

        lastResult = r;
        lastMixing = mixing;
        showResultImage(r, mixing);
        shareButton.setEnabled(true);
    }

    private void showResultImage(Calculator.Result r, boolean mixing) {
        try {
            Bitmap bmp = PlanRenderer.render(this, r, mixing);
            resultImage.setImageBitmap(bmp);
            resultImage.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Toast.makeText(this, "Render failed: " + e.getMessage(),
                           Toast.LENGTH_LONG).show();
        }
    }

    private void doShare() {
        if (lastResult == null) return;
        try {
            Bitmap bmp = PlanRenderer.render(this, lastResult, lastMixing);
            Uri uri = PlanRenderer.saveAndGetShareUri(this, bmp);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Share plan"));
        } catch (Exception e) {
            Toast.makeText(this, "Failed: " + e.getMessage(),
                           Toast.LENGTH_LONG).show();
        }
    }
}