package com.RustM.calculator;

import java.util.*;

public class Recipes {
    public static final String[] ITEMS = {
        "Gunpowder",
        "Explosives",
        "5.56 Ammo",
        "Incendiary 5.56 Ammo",
        "5.56 Explosive Ammo",
        "Rocket",
        "High Velocity Rocket",
        "Pistol Bullet",
        "Incendiary Pistol Bullet",
        "12 Gauge Incendiary Shell",
        "Satchel",
        "C4",
        "Molotov"
    };

    public static final Map<String, Map<String, Integer>> RECIPES = new HashMap<>();
    public static final Map<String, Integer> BATCH_SIZE = new HashMap<>();

    public static final Set<String> RAW_MATERIALS = new HashSet<>(Arrays.asList(
        "sulfur ore", "wood", "charcoal", "metal fragments", "low grade fuel",
        "metal pipe", "rope", "cloth", "tech trash", "wood storage box"
    ));

    public static final Map<String, int[]> FURNACE_RATES = new HashMap<>();

    public static final int GUNPOWDER_PER_BATCH = 20;
    public static final double GUNPOWDER_SECS_PER_BATCH = 3.2;

    static {
        put("sulfur", map("sulfur ore", 4, "wood", 1));
        put("charcoal", map("wood", 1));
        put("gunpowder", map("charcoal", 60, "sulfur", 40));
        put("gunpowder_mixing", map("sulfur", 40, "charcoal", 40));
        put("beancan grenade", map("gunpowder", 60, "metal fragments", 20));
        put("explosives", map("gunpowder", 50, "low grade fuel", 3,
                              "sulfur", 10, "metal fragments", 10));
        put("5.56 ammo", map("metal fragments", 40, "gunpowder", 20));
        put("incendiary 5.56 ammo",
            map("metal fragments", 50, "gunpowder", 50, "sulfur", 25));
        put("5.56 explosive ammo",
            map("metal fragments", 50, "gunpowder", 100, "sulfur", 50));
        put("rocket", map("metal pipe", 2, "gunpowder", 150, "explosives", 10));
        put("high velocity rocket", map("metal pipe", 1, "sulfur", 100));
        put("pistol bullet", map("metal fragments", 30, "gunpowder", 15));
        put("incendiary pistol bullet",
            map("metal fragments", 30, "gunpowder", 30, "sulfur", 15));
        put("12 gauge incendiary shell",
            map("metal fragments", 25, "gunpowder", 50, "sulfur", 100));
        put("satchel", map("beancan grenade", 4, "wood storage box", 1, "rope", 1));
        put("c4", map("explosives", 20, "cloth", 5, "tech trash", 2));
        put("molotov", map("cloth", 10, "low grade fuel", 50));
        put("wood storage box", map("wood", 100));

        batch("sulfur", 4);
        batch("gunpowder", 20);
        batch("gunpowder_mixing", 20);
        batch("5.56 ammo", 12);
        batch("incendiary 5.56 ammo", 10);
        batch("5.56 explosive ammo", 10);
        batch("pistol bullet", 12);
        batch("incendiary pistol bullet", 12);
        batch("12 gauge incendiary shell", 10);

        FURNACE_RATES.put("charcoal", new int[]{60, 40});
        FURNACE_RATES.put("sulfur ore", new int[]{240, 200});
        FURNACE_RATES.put("metal fragments", new int[]{120, 200});
    }

    private static void put(String k, Map<String, Integer> v) { RECIPES.put(k, v); }
    private static void batch(String k, int v) { BATCH_SIZE.put(k, v); }

    private static Map<String, Integer> map(Object... kv) {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2)
            m.put((String) kv[i], (Integer) kv[i + 1]);
        return m;
    }
}