package com.RustM.calculator;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class PlanRenderer {

    private static final int W = 1200;
    private static final int PAD = 40;
    private static final int LINE_H = 80;

    private static final int COL_BG      = 0xFF1C1E22;
    private static final int COL_CARD    = 0xFF2D3036;
    private static final int COL_ACCENT  = 0xFFD85837;
    private static final int COL_TEXT    = 0xFFEBEBEB;
    private static final int COL_DIM     = 0xFFB9BEC3;
    private static final int COL_GOOD    = 0xFF91DC91;
    private static final int COL_LINE    = 0xFF3C3F46;

    public static Bitmap render(Context ctx, Calculator.Result r, boolean mixing) {
        int estH = estimateHeight(r, mixing);
        Bitmap bmp = Bitmap.createBitmap(W, estH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(COL_BG);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextSize(26);

        int y = PAD;

        RectF header = new RectF(PAD, y, W - PAD, y + 180);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(COL_CARD);
        c.drawRoundRect(header, 20, 20, bg);

        Drawable icon = loadIcon(ctx, r.item);
        if (icon != null) {
            icon.setBounds(PAD + 30, y + 30, PAD + 30 + 120, y + 30 + 120);
            icon.draw(c);
        }

        p.setColor(COL_DIM);
        p.setTextSize(22);
        c.drawText("CRAFTING PLAN", PAD + 180, y + 70, p);

        p.setColor(COL_TEXT);
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(40);
        c.drawText(r.qty + "x " + r.item, PAD + 180, y + 130, p);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextSize(26);

        y += 180 + 40;

        y = drawSection(ctx, c, p, y, "RAW MATERIALS", buildRawLines(r));
        y = drawSection(ctx, c, p, y, "DIRECT INGREDIENTS", buildDirectLines(r));
        if (r.hasCraftTime)
            y = drawSection(ctx, c, p, y, "CRAFTING TIME", singleLine(r.craftTimeText));
        y = drawSection(ctx, c, p, y, "FURNACE TIME", buildFurnaceLines(r));
        if (r.hasCraftTime && r.grandTotalSecs > 0)
            y = drawSection(ctx, c, p, y, "GRAND TOTAL", buildGrandLines(r));

        int realH = Math.min(bmp.getHeight(), y + 80);
        if (realH < bmp.getHeight()) {
            Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, W, realH);
            bmp.recycle();
            bmp = cropped;
        }
        return bmp;
    }

    private static int drawSection(Context ctx, Canvas c, Paint p, int y,
                                   String title, List<String[]> rows) {
        p.setColor(COL_ACCENT);
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(32);
        c.drawText(title, PAD + 10, y + 40, p);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextSize(26);
        y += 60;

        Paint line = new Paint();
        line.setColor(COL_LINE);
        line.setStrokeWidth(2);
        c.drawLine(PAD, y, W - PAD, y, line);
        y += 20;

        for (String[] row : rows) {
            String iconKey = row[0];
            String label = row[1];
            String value = row.length > 2 ? row[2] : null;
            boolean isSub = iconKey != null && iconKey.startsWith("SUB:");

            if (isSub) {
                Drawable ic = loadIcon(ctx, iconKey.substring(4));
                if (ic != null) {
                    ic.setBounds(PAD + 60, y + 10, PAD + 60 + 44, y + 10 + 44);
                    ic.draw(c);
                }
                p.setColor(COL_DIM);
                p.setTextSize(24);
                c.drawText(label, PAD + 120, y + 50, p);
                p.setTextSize(26);
                y += 60;
                continue;
            }

            if (iconKey != null) {
                Drawable ic = loadIcon(ctx, iconKey);
                if (ic != null) {
                    ic.setBounds(PAD + 10, y + 10, PAD + 10 + 56, y + 10 + 56);
                    ic.draw(c);
                }
            }

            p.setColor(COL_TEXT);
            c.drawText(label, PAD + 90, y + 55, p);

            if (value != null) {
                p.setColor(COL_GOOD);
                float vw = p.measureText(value);
                c.drawText(value, W - PAD - 20 - vw, y + 55, p);
            }
            y += LINE_H;
        }
        return y + 30;
    }

    private static Drawable loadIcon(Context ctx, String key) {
        if (key == null) return null;
        try {
            String fn = IconMap.filenameFor(key);
            if (fn == null) return null;
            InputStream is = ctx.getAssets().open("icons/" + fn);
            Drawable d = Drawable.createFromStream(is, null);
            is.close();
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    private static List<String[]> buildRawLines(Calculator.Result r) {
        java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
        long charcoal = r.raw.getOrDefault("charcoal", 0L);
        long storage = r.raw.getOrDefault("wood storage box", 0L);
        long directWood = r.raw.getOrDefault("wood", 0L);
        long sulfurWood = (r.sulfurUsed + 3) / 4;
        long totalWood = directWood + charcoal + storage * 100;

        if (totalWood > 0) {
            out.add(new String[]{"wood", "Wood", Calculator.fmt(totalWood)});
            if (sulfurWood > 0)
                out.add(new String[]{"SUB:sulfur ore",
                    Calculator.fmt(sulfurWood) + " wood for smelting sulfur", null});
            if (charcoal > 0)
                out.add(new String[]{"SUB:charcoal",
                    Calculator.fmt(charcoal) + " wood for charcoal", null});
            if (storage > 0)
                out.add(new String[]{"SUB:wood storage box",
                    Calculator.fmt(storage * 100) + " wood for storage box", null});
        }
        for (Map.Entry<String, Long> e : r.raw.entrySet()) {
            String k = e.getKey();
            if (k.equals("wood") || k.equals("wood storage box")) continue;
            out.add(new String[]{k, titleCase(k), Calculator.fmt(e.getValue())});
        }
        if (storage > 0)
            out.add(new String[]{"wood storage box", "Wood Storage Box",
                Calculator.fmt(storage)});
        return out;
    }

    private static List<String[]> buildDirectLines(Calculator.Result r) {
        java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
        for (Map.Entry<String, Long> e : r.direct.entrySet()) {
            String ing = e.getKey();
            out.add(new String[]{ing, titleCase(ing), Calculator.fmt(e.getValue())});

            List<String[]> notes = r.directNotes.get(ing.toLowerCase().trim());
            if (notes != null)
                for (String[] note : notes)
                    out.add(new String[]{"SUB:" + note[0], note[1], null});
        }
        return out;
    }

    private static List<String[]> buildFurnaceLines(Calculator.Result r) {
        java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
        for (String[] row : r.furnaceRows) {
            out.add(new String[]{row[0],
                titleCase(row[0]) + " (" + row[1] + " batches)", row[2]});
        }
        if (!r.furnaceRows.isEmpty()) {
            out.add(new String[]{"SUB:furnace",
                "Total (one furnace): " + Calculator.hms(r.furnaceTotalSecs), null});
            out.add(new String[]{"SUB:furnace",
                "Total (" + r.furnaceCount + " furnaces): "
                + Calculator.hms(r.furnaceLongestSecs), null});
        }
        return out;
    }

    private static List<String[]> buildGrandLines(Calculator.Result r) {
        java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
        long craftSecs = r.grandTotalSecs - r.furnaceTotalSecs;
        if (craftSecs > 0)
            out.add(new String[]{null, "Crafting time", Calculator.hms(craftSecs)});
        out.add(new String[]{null, "Furnace time", Calculator.hms(r.furnaceTotalSecs)});
        out.add(new String[]{null, "Grand total", Calculator.hms(r.grandTotalSecs)});
        return out;
    }

    private static List<String[]> singleLine(String s) {
        java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
        out.add(new String[]{null, s, null});
        return out;
    }

    private static int estimateHeight(Calculator.Result r, boolean mixing) {
        int h = PAD + 180 + 40;
        h += sectionH(buildRawLines(r));
        h += sectionH(buildDirectLines(r));
        if (r.hasCraftTime) h += sectionH(singleLine(r.craftTimeText));
        h += sectionH(buildFurnaceLines(r));
        if (r.hasCraftTime && r.grandTotalSecs > 0) h += sectionH(buildGrandLines(r));
        return h + 120;
    }

    private static int sectionH(List<String[]> rows) {
        int h = 60 + 20;
        for (String[] row : rows)
            h += (row[0] != null && row[0].startsWith("SUB:")) ? 60 : LINE_H;
        return h + 30;
    }

    private static String titleCase(String s) {
        StringBuilder sb = new StringBuilder();
        for (String w : s.split(" "))
            if (!w.isEmpty())
                sb.append(Character.toUpperCase(w.charAt(0)))
                  .append(w.substring(1)).append(' ');
        return sb.toString().trim();
    }

    public static Uri saveAndGetShareUri(Context ctx, Bitmap bmp) throws Exception {
        File dir = new File(ctx.getCacheDir(), "shared");
        dir.mkdirs();
        File out = new File(dir, "rust_plan.png");
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();

        return FileProvider.getUriForFile(ctx,
            ctx.getPackageName() + ".fileprovider", out);
    }
}