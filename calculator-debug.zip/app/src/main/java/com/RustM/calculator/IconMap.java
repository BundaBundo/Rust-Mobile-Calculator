package com.RustM.calculator;

import java.util.HashMap;
import java.util.Map;

public class IconMap {
    private static final Map<String, String> M = new HashMap<>();

    static {
        M.put("wood", "wood.png");
        M.put("charcoal", "Charcoal_icon.webp");
        M.put("sulfur ore", "Sulfur_Ore_icon.webp");
        M.put("sulfur", "Sulfur_icon.webp");
        M.put("metal fragments", "Metal_Fragments_icon.webp");
        M.put("low grade fuel", "Low_Grade_Fuel_icon.webp");
        M.put("metal pipe", "metalpipe.webp.png");
        M.put("rope", "Rope_icon.webp");
        M.put("cloth", "Cloth_icon.webp");
        M.put("tech trash", "techparts.webp.png");
        M.put("wood storage box", "Wood_Storage_Box_icon.webp");
        M.put("gunpowder", "Gun_Powder_icon.webp");
        M.put("explosives", "Explosives_icon.webp");
        M.put("5.56 ammo", "5.56_Rifle_Ammo_icon.webp");
        M.put("incendiary 5.56 ammo", "Incendiary_5.56_Rifle_Ammo_icon.webp");
        M.put("5.56 explosive ammo", "Explosive_5.56_Rifle_Ammo_icon.webp");
        M.put("rocket", "Rocket_icon.webp");
        M.put("high velocity rocket", "High_Velocity_Rocket_icon.webp");
        M.put("pistol bullet", "Pistol_Bullet_icon.webp");
        M.put("incendiary pistol bullet", "Incendiary_Pistol_Bullet_icon.webp");
        M.put("12 gauge incendiary shell", "Ammo.shotgun.fire.webp");
        M.put("beancan grenade", "Beancan_Grenade_icon.webp");
        M.put("satchel", "explosive.satchel.png");
        M.put("c4", "Timed_Explosive_Charge_icon.webp");
        M.put("molotov", "grenade-molotov.webp.png");
        M.put("furnace", "Furnace_icon.webp");
        M.put("rust", "icon_rust.png");
    }

    public static String filenameFor(String key) {
        if (key == null) return null;
        return M.get(key.toLowerCase().trim());
    }
}