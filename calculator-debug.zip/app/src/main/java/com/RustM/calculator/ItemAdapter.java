package com.RustM.calculator;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;

public class ItemAdapter extends BaseAdapter {

    private final Context ctx;
    private final String[] items;
    private final LayoutInflater inflater;

    public ItemAdapter(Context ctx, String[] items) {
        this.ctx = ctx;
        this.items = items;
        this.inflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() { return items.length; }

    @Override
    public Object getItem(int position) { return items[position]; }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return bind(position, convertView, parent, R.layout.spinner_item);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return bind(position, convertView, parent, R.layout.spinner_dropdown_item);
    }

    private View bind(int position, View convertView, ViewGroup parent, int layoutRes) {
        View v = convertView;
        if (v == null) {
            v = inflater.inflate(layoutRes, parent, false);
        }

        ImageView icon = v.findViewById(R.id.spinnerIcon);
        TextView text = v.findViewById(R.id.spinnerText);

        String name = items[position];
        text.setText(name);
        icon.setImageDrawable(loadIcon(name));

        return v;
    }

    private Drawable loadIcon(String itemName) {
        try {
            String fn = IconMap.filenameFor(itemName);
            if (fn == null) return null;
            InputStream is = ctx.getAssets().open("icons/" + fn);
            Drawable d = Drawable.createFromStream(is, null);
            is.close();
            return d;
        } catch (Exception e) {
            return null;
        }
    }
}